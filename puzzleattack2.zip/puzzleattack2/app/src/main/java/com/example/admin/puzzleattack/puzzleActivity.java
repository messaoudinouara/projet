package com.example.admin.puzzleattack;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class puzzleActivity extends AppCompatActivity {
    private puzzleView1 mpuzzleView;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // initialise notre activity avec le constructeur parent
        super.onCreate(savedInstanceState);
        // charge le fichier main.xml comme vue de l'activit�
        setContentView(R.layout.activity_puzzle);
        // recuperation de la vue une voie cree � partir de son id
        mpuzzleView = (puzzleView1)findViewById(R.id.puzzleView1);
        // rend visible la vue
        mpuzzleView.setVisibility(View.VISIBLE);
    }
}

