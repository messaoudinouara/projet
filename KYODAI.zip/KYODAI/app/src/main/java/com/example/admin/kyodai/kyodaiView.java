package com.example.admin.kyodai;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.method.LinkMovementMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * Created by admin on 10/04/2016.
 */
public class kyodaiView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    private kyodai active;

    // initialisation des papillons
    private Bitmap pap1;
    private Bitmap pap2;
    private Bitmap pap3;
    private Bitmap pap4;
    private Bitmap pap5;
    private Bitmap pap6;
    private Bitmap pap7;
    private Bitmap pap8;
    private Bitmap pap9;
    private Bitmap pap10;
    private Bitmap vide;

    private Resources mRes;
    private Context mContext;
    int score = 0;
    boolean clic = false; //teste la touche sur l'interface
    boolean xx;

    // tableau modelisant la carte du jeu
    int[][] carte;


    // ancres pour pouvoir centrer la carte du jeu
    int carteTopAnchor;                   // coordonn�es en Y du point d'ancrage de notre carte
    int carteLeftAnchor;

    static final int carteWidth = 8;
    static final int carteHeight = 8;
    static final int carteTileSize = 60;


    // constante modelisant les differentes types de cases

    static final int CST_capture10 = 10;
    static final int CST_capture9 = 9;
    static final int CST_capture8 = 8;
    static final int CST_capture7 = 7;
    static final int CST_capture6 = 6;
    static final int CST_capture5 = 5;
    static final int CST_capture4 = 4;
    static final int CST_capture3 = 3;
    static final int CST_capture2 = 2;
    static final int CST_capture1 = 1;
    static final int CST_cap = 0;


    int[][] sup; // vecteur utiliser a la suprission des case de meme couleur
    int[] depX = {36, 141, 247};
    int[] depY = {330, 330, 330};


    // tableau de reference du terrain
    int[][] ref1 = {
            {CST_capture5, CST_capture1, CST_capture5, CST_capture1, CST_capture3, CST_capture2, CST_capture3, CST_capture2},
            {CST_capture6, CST_capture2, CST_cap, CST_cap, CST_capture2, CST_capture2, CST_capture6, CST_capture2},
            {CST_capture6, CST_capture3, CST_capture7, CST_capture7, CST_cap, CST_cap, CST_capture3, CST_capture6},
            {CST_capture9, CST_cap, CST_capture9, CST_capture8, CST_cap, CST_capture8, CST_capture8, CST_capture8},
            {CST_capture7, CST_capture3, CST_cap, CST_cap, CST_cap, CST_capture7, CST_capture3, CST_cap},
            {CST_capture5, CST_cap, CST_capture9, CST_capture7, CST_cap, CST_capture7, CST_capture3, CST_capture2},
            {CST_cap, CST_capture4, CST_cap, CST_capture4, CST_cap, CST_cap, CST_capture3, CST_capture2},
            {CST_capture5, CST_capture1, CST_capture9, CST_capture1, CST_cap, CST_capture10, CST_capture9, CST_capture10}

    };
    int[][] refdiamants = {
            {2, 3},
            {2, 6},
            {6, 3},
            {6, 6}
    };

    // position de reference du joueur
    int refxPlayer = 4;
    int refyPlayer = 1;



    // position courante du joueur
    int xPlayer = 4;
    int yPlayer = 1;


    private boolean in = true;
    private Thread cv_thread;
    SurfaceHolder holder;

    Paint paint;

    public kyodaiView(Context context, AttributeSet attrs) {
        super(context, attrs);

        active = new kyodai();
        // permet d'ecouter les surfaceChanged, surfaceCreated, surfaceDestroyed
        holder = getHolder();
        holder.addCallback(this);

        // chargement des images
        mContext = context;
        mRes = mContext.getResources();
        vide = BitmapFactory.decodeResource(mRes, R.drawable.cap);
        pap1 = BitmapFactory.decodeResource(mRes, R.drawable.capture1);
        pap2 = BitmapFactory.decodeResource(mRes, R.drawable.capture2);
        pap3 = BitmapFactory.decodeResource(mRes, R.drawable.capture3);
        pap4 = BitmapFactory.decodeResource(mRes, R.drawable.capture4);
        pap5 = BitmapFactory.decodeResource(mRes, R.drawable.capture5);
        pap6 = BitmapFactory.decodeResource(mRes, R.drawable.capture6);
        pap7 = BitmapFactory.decodeResource(mRes, R.drawable.capture7);
        pap8 = BitmapFactory.decodeResource(mRes, R.drawable.capture8);
        pap9 = BitmapFactory.decodeResource(mRes, R.drawable.capture9);
        pap10 = BitmapFactory.decodeResource(mRes, R.drawable.capture10);

        // initialisation des paramétres du jeu
        initparameters();

        // creation du thread
        cv_thread = new Thread(this);
        // prise de focus pour gestion des touches
        setFocusable(true);

    }

    private void loadlevel() {
        for (int i = 0; i < carteHeight; i++) {
            for (int j = 0; j < carteWidth; j++) {

                carte[j][i] = ref1[j][i];


            }
        }

    }


    public void initparameters() {

        xx = true;
        if (score == 0) {
            carte = new int[carteHeight][carteWidth];

            loadlevel();

        }
        carteTopAnchor = (getHeight() - carteHeight * carteTileSize) / 2;
        carteLeftAnchor = (getWidth() - carteWidth * carteTileSize) / 2;
        xPlayer = refxPlayer;
        yPlayer = refyPlayer;

        if ((cv_thread != null) && (!cv_thread.isAlive())) {
            cv_thread.start();
            Log.e("-FCT-", "cv_thread.start()");
        }
    }

    private void showAbout() {
        final boolean[] reponse = new boolean[1];
        AlertDialog.Builder about = new AlertDialog.Builder(mContext);
        about.setTitle("Oops");
        TextView l_viewabout = new TextView(mContext);


        l_viewabout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT));
        l_viewabout.setPadding(20, 10, 20, 10);
        l_viewabout.setTextSize(20);
        l_viewabout.setText(" - Votre score:" + score + "\n \n- Voulez vous Continuer");

        l_viewabout.setMovementMethod(LinkMovementMethod.getInstance());
        about.setView(l_viewabout);
        about.setPositiveButton("OUI", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                score = 0;
                initparameters();

            }

        });
        about.setNegativeButton("NON", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                active.finish();


            }

        });
        about.show();
    }

    public void text(Canvas canvas) {

        String xt = Integer.toString(score);
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(12);
        canvas.drawText(xt, 50, 462, paint);
    }




    private void nDraw(Canvas canvas) {

        canvas.drawRGB(48, 48, 48);

            paintcarte(canvas);
            text(canvas);


    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.i("-> FCT <-", "surfaceChanged " + width + " - " + height);
        initparameters();
    }

    public void supprime() {

        sup = new int[8][8];

        int ind1 = 0;
        for (int i = 0; i < carteWidth; i++) {
            if (i == 0) {
                int val = carte[0][0];
                int h = 0;
                for (int j = 1; j < carteHeight; j++) {

                    if (carte[i][j] == val && val != 0) {
                        ind1 = j;
                        sup[0][h] = ind1;
                        h++;
                    }
                }
            }
            if (i == 7) {
                int val = carte[7][0];
                int h = 0;
                for (int j = 1; j < carteHeight; j++) {
                    if (carte[i][j] == val && val != 0) {
                        ind1 = j;
                        sup[7][h] = ind1;
                        h++;
                    }
                }
            }
        }
        for (int j = 1; j < carteHeight; j++) {
            if (j == 0) {
                int val = carte[0][0];
                int h = 0;
                for (int i = 1; j < carteWidth; j++) {
                    if (carte[i][j] == val && val != 0) {
                        ind1 = i;
                        sup[h][0] = ind1;
                        h++;
                    }
                }
            }
            if (j == 7) {
                int val = carte[0][7];
                int h = 0;
                for (int i = 1; j < carteWidth; j++) {
                    if (carte[i][j] == val && val != 0) {
                        ind1 = i;
                        sup[h][7] = ind1;
                        h++;
                    }
                }

            }
        }

    }


    public void surfaceCreated(SurfaceHolder arg0) {
        Log.i("-> FCT <-", "surfaceCreated");
    }


    public void surfaceDestroyed(SurfaceHolder arg0) {

        Log.i("-> FCT <-", "surfaceDestroyed");
    }

    public void run() {
        Canvas c = null;
        while (in) {
            try {
                cv_thread.sleep(60);

                try {
                    c = holder.lockCanvas(null);
                    nDraw(c);
                } finally {
                    if (c != null) {
                        holder.unlockCanvasAndPost(c);
                    }
                }
            } catch (Exception e) {
               // Log.e("-> RUN <-", "PB DANS RUN");
            }
        }
    }

    private void paintcarte(Canvas canvas) {
        for (int i = 0; i < carteHeight; i++) {
            for (int j = 0; j < carteWidth; j++) {
                switch (carte[i][j]) {
                    case CST_cap:
                        canvas.drawBitmap(vide, (j * carteTileSize)/2, (i * carteTileSize)/2 , null);
                        break;
                    case CST_capture1:
                        canvas.drawBitmap(pap1, (j * carteTileSize)/2 , (i * carteTileSize)/2, null);
                        break;
                    case CST_capture2:
                        canvas.drawBitmap(pap2, (j * carteTileSize)/2, (i * carteTileSize)/2, null);
                        break;
                    case CST_capture3:
                        canvas.drawBitmap(pap3, (j * carteTileSize)/2, (i * carteTileSize)/2, null);
                        break;
                    case CST_capture4:
                        canvas.drawBitmap(pap4, (j * carteTileSize)/2 , (i * carteTileSize)/2 , null);
                        break;
                    case CST_capture5:
                        canvas.drawBitmap(pap5, (j * carteTileSize)/2 , (i * carteTileSize)/2 , null);
                        break;
                    case CST_capture6:
                        canvas.drawBitmap(pap6, (j * carteTileSize)/2, (i * carteTileSize)/2, null);
                        break;
                    case CST_capture7:
                        canvas.drawBitmap(pap7, (j * carteTileSize)/2 , (i * carteTileSize)/2 , null);
                        break;
                    case CST_capture8:
                        canvas.drawBitmap(pap8, (j * carteTileSize)/2, (i * carteTileSize)/2 , null);
                        break;
                    case CST_capture9:
                        canvas.drawBitmap(pap9, (j * carteTileSize)/2 , (i * carteTileSize)/2 , null);
                        break;
                    case CST_capture10:
                        canvas.drawBitmap(pap10, (j * carteTileSize)/2 , (i * carteTileSize)/2 , null);
                        break;

                }
            }
        }
    }



    public boolean onTouchEvent(MotionEvent event) {
        final int y = (int) event.getY();
        final int x = (int) event.getX();
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            Log.i("-> FCT <-", "onTouchEvent: ");

            if (y > 60 && y < 370) {
                clic = true;

            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (clic) {
                    supprime();
                }
            }



        }
        return true;

    }
}